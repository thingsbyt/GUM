# GUM Concept Genesis + Real Data Rescue

**Overall verdict: both frozen, precommitted audits passed.**

## What changed

The earlier Growth Challenge gave GUM a hand-written five-way visual-change signature. Concept Genesis removes that vocabulary. It learns pixel-change tokens from raw before/after frames, compares candidate partitions, selects its own concept count from unlabeled evidence, and uses the resulting opaque concepts to compile and compose skills.

The old signature could distinguish only **3 of 5** mechanisms in the new worlds. Concept Genesis autonomously selected **5 concepts**, and the audit-only hidden-state comparison found a perfect one-to-one correspondence with all five mechanisms.

## Frozen visual audit

- Concepts selected without a requested count: **5**
- Curriculum worlds solved: **4/4**
- Unseen appearances and control mappings: **20/20**
- Skills retained after save/reload: **4/4**
- Two distinct skills composed in the post-training fifth world: **yes**
- Experienced interactions: **83**
- Perception-matched blank interactions: **41,339**
- Experience advantage: **498.06×**
- Frozen source, valid hash-chained traces, and no hidden-state fields in learner traces: **passed**

## Frozen real-file audit

The unchanged Concept Genesis learner was then placed in a different domain. Its anonymous actions operated on actual JSONL working files. It was not given operation names, field names, control mappings, the correct order, validation rules, a concept count, or a solution.

- File-operation concepts selected autonomously: **5**
- Training file repaired and independently verified: **yes**
- Unseen JSONL files repaired: **5/5**
- Workflow retained after save/reload: **yes**
- Experienced interactions on an unseen file: **10**
- Perception-matched blank interactions: **3,480**
- Experience advantage: **348×**
- Clean JSONL and CSV outputs produced: **yes**
- Original input files byte-for-byte unchanged: **yes**
- Exact Concept Genesis implementation shared with visual audit: **yes**

## Meaning

This is stronger than memorizing action sequences or using a predefined event vocabulary. The same frozen learning algorithm formed different useful concept systems in a visual mechanism domain and a real-file workflow domain, retained them, and used experience to reduce later search dramatically.

The current perceptual bias still assumes that changed pixels and distributions of learned pixel tokens are useful. The data environment also supplies five safe file operations and a visual quality view. The next research target is to learn attention and object boundaries directly, then allow GUM to select or construct tools rather than receiving a fixed tool set.

## Primary evidence

- `gum_concept_genesis_v1/CONCEPT_GENESIS_PROTOCOL.json`
- `gum_concept_genesis_v1/CONCEPT_GENESIS_AUDIT.json`
- `gum_concept_genesis_v1/CONCEPT_GENESIS_REPLAY.gif`
- `gum_data_rescue_genesis_v1/DATA_RESCUE_PROTOCOL.json`
- `gum_data_rescue_genesis_v1/DATA_RESCUE_AUDIT.json`
- `gum_data_rescue_genesis_v1/CLEANED_OUTPUTS/`
- `gum_data_rescue_genesis_v1/GROWING_MIND_PORTFOLIO.json`
- Both audit folders contain frozen source snapshots and hash-chained transition traces.
